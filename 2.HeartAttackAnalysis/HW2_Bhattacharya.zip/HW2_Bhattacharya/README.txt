CS584 HOMEWORK 2
NAME : Preeti Bhattacharya (G01302375)

READ ME FILE

How to run my code.



1) Use .ipnyb extension file on to google collab Pro(I used google collab because my system was crashing or was taking too long to execute).
2) Import 1644871288_9762487_cleveland-train.csv file for training data set.
3) Import 1644871288_9775174_cleveland-test.csv file for testing data set.
4) Run the code in google collab for each cell.
5) In the 11th cell where I'm calculating the values there in the last line (given below) you can change the values of iteration and eta and see different graphs forming,
   which can help you understand the flow.
         "preditcted_weight, predicted_bias, y_pred=logistic_regression(x_train,y_train,x_test,y_test,0.00001,100000)"
6) We then write output to a text file, which can be found in file section of google collab.





